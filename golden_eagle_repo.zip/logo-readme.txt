Replace this with a stylish eagle PNG. Example filename: app/assets/eagle.png
